require "test/unit"

require File.expand_path(File.dirname(__FILE__) + "/../../lib/provinces")

class TestProvinces < Test::Unit::TestCase  
  def test_full_name
    assert_equal "Ontario", Provinces::full_name("ON")
  end
end