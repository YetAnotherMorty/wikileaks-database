require File.dirname(__FILE__) + '/../test_helper'

class AccessPassTest < Test::Unit::TestCase
  fixtures :access_passes

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
