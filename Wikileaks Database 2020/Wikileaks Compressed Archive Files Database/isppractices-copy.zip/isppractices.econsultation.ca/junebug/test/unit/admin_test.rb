require File.dirname(__FILE__) + '/../test_helper'

class AdminTest < Test::Rails::TestCase
  fixtures :users

  # Test admin role
  def test_role
    assert_equal :admin, Admin.find(:first).role
  end
  
end
