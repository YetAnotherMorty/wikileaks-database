require File.dirname(__FILE__) + '/../test_helper'

class RegisteredGuestTest < Test::Unit::TestCase
  fixtures :users

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
