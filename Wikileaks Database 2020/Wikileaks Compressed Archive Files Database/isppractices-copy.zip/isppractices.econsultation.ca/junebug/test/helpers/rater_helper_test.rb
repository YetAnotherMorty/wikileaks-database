require File.dirname(__FILE__) + '/../test_helper'
require 'mocha'
require 'abstract_rating'

class RaterHelperTest < HelperTestCase

  include RaterHelper

  fixtures :ratings

  def setup
    super
  end
  
  def test_rate_select_intro
    assert_match " Rate as... ", rate_select_intro(TopicRating.new)
    assert_match " Rate as... ", rate_select_intro(CommentRating.new)
    assert_match "...", rate_select_intro(MaterialConvincingRating.new)
    assert_match "...", rate_select_intro(MaterialInformativeRating.new)
  end
  
end
