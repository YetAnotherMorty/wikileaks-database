require File.dirname(__FILE__) + '/../test_helper'
require 'mocha'

class TopicsHelperTest < HelperTestCase

  include TopicsHelper
  include ApplicationHelper

  fixtures :users, :comments, :topics

  def setup
    super
  end
  
  def test_latest_commenter_on
    assert_equal 'Grace', latest_commenter_on(topics(:direct_democracy))
  end
  
  # def test_edit_links
  #   raise NotImplementedError, 'Need to write test_edit_links'
  # end
  # 
  # def test_library_box
  #   raise NotImplementedError, 'Need to write test_library_box'
  # end

  # !@most_read_comments.empty? && !@highest_rated_comments.empty?
  def test_show_hot_comments_eh
    @most_read_comments     = [1]
    @highest_rated_comments = [1]
    assert show_hot_comments?
  end

  def test_show_hot_comments_eh_one_empty
    @most_read_comments     = []
    @highest_rated_comments = [1]
    assert !show_hot_comments?
  end

  def test_show_hot_comments_eh_both_empty
    @most_read_comments     = []
    @highest_rated_comments = []
    assert !show_hot_comments?
  end
end
