require File.dirname(__FILE__) + '/../test_helper'

class FeedsHelperTest < HelperTestCase
  
  include FeedsHelper
  
  def test_topic_pubDate
    assert_equal 'Sun, 22 Jan 2006 07:00:00 GMT', topic_pubDate(Topic.new(:start_date => '2006-01-22'))
  end
  
end