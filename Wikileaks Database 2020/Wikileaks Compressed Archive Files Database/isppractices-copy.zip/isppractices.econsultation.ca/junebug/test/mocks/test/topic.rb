require 'models/topic'

class Topic
  @@index = false
  def index_repr(f)
    @@index ? super : []
  end
end
