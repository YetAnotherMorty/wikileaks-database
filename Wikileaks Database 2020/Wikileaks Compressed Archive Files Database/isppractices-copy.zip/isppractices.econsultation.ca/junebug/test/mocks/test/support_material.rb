require 'models/support_material'

class SupportMaterial
  def full_filename(thumbnail = nil)
    file_system_path = (thumbnail ? thumbnail_class : self).attachment_options[:path_prefix].to_s
    File.join(Dir::tmpdir(), file_system_path, *partitioned_path(thumbnail_name_for(thumbnail)))
    # File.join(RAILS_ROOT, '..', 'test', 'tmp', file_system_path, *partitioned_path(thumbnail_name_for(thumbnail)))
  end  
  
  def destroy_file
  end
end

