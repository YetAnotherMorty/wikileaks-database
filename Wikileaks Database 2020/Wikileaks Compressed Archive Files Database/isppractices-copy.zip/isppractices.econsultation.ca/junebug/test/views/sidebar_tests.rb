require File.dirname(__FILE__) + '/../test_helper'

# Create a dummy controller for layout views. This lets the setup use the
# right path with minimum fuss.
class SidebarsController < ApplicationController; end

class SidebarsViewTest < Test::Rails::ViewTestCase

  def test_search_partial
    render :partial => '/sidebar/search'
    
    assert_tag :tag => 'form',  :attributes => { :action => '/search/', :method => 'get' }
    assert_tag :tag => 'input', :attributes => { :id => "terms" }
  end

end