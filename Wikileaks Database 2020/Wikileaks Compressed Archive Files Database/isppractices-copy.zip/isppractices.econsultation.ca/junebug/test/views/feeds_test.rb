require File.dirname(__FILE__) + '/../test_helper'

class FeedsViewTest < Test::Rails::ViewTestCase

  fixtures :topics, :settings, :comments
  
  def test_rss
    assigns[:feed_title]       = Settings.consultation_name
    assigns[:feed_link]        = Settings.application_url
    assigns[:feed_description] = Settings.consultation_description
    assigns[:topics]           = Topic.find(:all, :order => '`start_date` DESC')
    
    render :action => 'rss'    
  end

end