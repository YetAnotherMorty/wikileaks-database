require File.dirname(__FILE__) + '/../test_helper'
require 'mocha'
require 'stubba'

class RaterViewTest < Test::Rails::ViewTestCase
 
  # page.replace_html @element_id, rating_widget(@rating)
  # page.visual_effect :pulsate, @element_id, {:from => 0.25, :pulses => 2}
  # page <<  %q{urchinTracker("/funnel/rating/success?type=%s?id=%d")} % [@rating.subject.class, @rating.subject.id]
  def test_update_comment_rjs_succeed
    c = Comment.new()
    c.stubs(:id).returns(7)
    assigns[:rating]     = CommentRating.new(:subject => c)
    assigns[:element_id] = "comment_rating_7"

    render :template => 'rater/update_comment.rjs'
      
    # assert_match %r{/funnel/rating/success?type=Comment&amp;id=7}, @response.body   # can't get this to agree with reality
  end
end
