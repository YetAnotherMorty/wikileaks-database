module RuportQueryOverArConnection
  
  # generate a report that responds to #as(:csv) and #as(:html)
  def report_raw(query)
    results = ActiveRecord::Base.connection.execute(query)
    names   = results.fetch_fields.collect(&:name)
    table   = Ruport::Data::Table.new(:column_names => names)
    results.each do |row|
      table << row
    end
    table
  end
  
end