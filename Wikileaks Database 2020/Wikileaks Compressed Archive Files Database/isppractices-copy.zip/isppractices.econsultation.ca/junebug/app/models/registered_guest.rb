# Schema as of Fri Jun 29 21:58:21 EDT 2007 (schema version 45)
#
#  id                  :integer(11)   not null
#  name                :string(255)   
#  type                :string(255)   
#  email               :string(100)   
#  crypted_password    :string(40)    
#  salt                :string(40)    
#  created_at          :datetime      
#  bio                 :text          
#  picture             :string(255)   
#  user_number         :string(255)   
#  year_of_birth       :integer(11)   
#  gender              :integer(11)   default(0)
#  postal_code         :string(255)   
#  login_key           :string(255)   
#  verified            :boolean(1)    
#  login_key_expires_at:datetime      
#  avg_rating          :float         
#  suspended           :boolean(1)    
#  receive_messages_fro:boolean(1)    default(true)
#

# This is for the demo user account
#
# The first one will be guest@sesresearch.com/guest
class RegisteredGuest < RegisteredUser

  def handle                                                                                  
    "Guest"
  end                                                                                         

  def guest?
    true
  end

end
