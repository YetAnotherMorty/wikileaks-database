class Message
  def initialize(sender, receiver, message_body)
    @sender, @receiver, @message_body = sender, receiver, message_body
  end
  
  def deliver!
    if ApplicationPolicy::can_send_message_to?(@sender, @receiver) # TODO test
      UserMessager::deliver_user_message(@sender, @receiver, @message_body)
    end
  end
end