class AccessPass < ActiveRecord::Base
  belongs_to :user
  belongs_to :topic
  belongs_to :registration_filter_item  
end
