class FeedsController < ApplicationController
  
  session :off
  skip_before_filter :setup_userstamp, 
                     :login_required, 
                     :logout_suspended_users
  
  def rss
    @feed_title       = Settings.consultation_name
    @feed_link        = Settings.application_url
    @feed_description = Settings.consultation_description
    @topics           = Guest.new.topics_find(:all, :order => '`start_date` DESC')
    render :layout => false
  end
end
