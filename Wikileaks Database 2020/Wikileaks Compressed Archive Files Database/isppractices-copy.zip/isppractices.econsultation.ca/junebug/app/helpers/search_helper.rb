module SearchHelper

  def range(results)
    return "none" if results.current_page > results.page_count
    first = results.per_page * (results.current_page-1) + 1
    last  = first + results.records.length
    "%d-%d" % [first, last]
  end
end
