module BlogHelper

  def blog_font_page_greeting
    out = []
    out << @blog_font_page_greeting.body unless @blog_font_page_greeting.new_record? 
    out << edit_snippet_link(@blog_font_page_greeting)
    out.join("\n")
  end  
  
  def blog_hot_comment(comment)
    hot_comment(comment) do
      link_to "...more", (topic_url(comment.topic_id) + "#comment_#{comment.id}")
    end
  end
end
