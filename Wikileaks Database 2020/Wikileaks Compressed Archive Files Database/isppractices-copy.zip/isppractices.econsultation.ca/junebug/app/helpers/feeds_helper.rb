module FeedsHelper
  def topic_pubDate(topic)
    CGI.rfc1123_date Time.parse(topic.start_date.to_s)
  end
end
