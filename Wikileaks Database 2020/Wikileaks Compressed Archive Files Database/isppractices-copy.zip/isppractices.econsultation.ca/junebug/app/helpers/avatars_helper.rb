module AvatarsHelper

  def img_user_avatar(user, size = nil)
    image_tag(user.avatar.public_filename(size))
  end

end
