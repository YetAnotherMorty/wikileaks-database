module UsersHelper
  def profile_owner?
    current_user == @profile
  end
end
