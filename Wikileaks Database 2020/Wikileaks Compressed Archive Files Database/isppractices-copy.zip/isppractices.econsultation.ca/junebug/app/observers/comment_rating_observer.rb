class CommentRatingObserver < ActiveRecord::Observer
  
  def after_create(rating)
    rating.comment.send(:callback, :after_rating_change)
  end
  
  def after_destroy(rating)
    rating.comment.send(:callback, :after_rating_change)
  end
  
end