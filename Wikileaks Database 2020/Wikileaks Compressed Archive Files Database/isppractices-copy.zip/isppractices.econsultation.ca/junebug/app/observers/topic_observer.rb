class TopicObserver < ActiveRecord::Observer
  # Add the expert to the whitelist filters
  def after_save(topic)
    topic.whitelist_filter_items.create(:value => topic.expert.email) unless topic.whitelist_filter_items.find_by_value(topic.expert.email)
  end
end
