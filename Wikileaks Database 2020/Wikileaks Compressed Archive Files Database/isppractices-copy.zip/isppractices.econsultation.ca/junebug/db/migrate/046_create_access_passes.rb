class CreateAccessPasses < ActiveRecord::Migration
  def self.up
    create_table :access_passes do |t|
      t.column :user_id, :integer
      t.column :topic_id, :integer
      t.column :registration_filter_item_id, :integer
    end
  end

  def self.down
    drop_table :access_passes
  end
end
