class CommentsGetReadCount < ActiveRecord::Migration
  def self.up
    add_column(:comments, :readings_count, :integer)
    Comment.find(:all).each{|c| c.update_attribute_with_validation_skipping(:readings_count, c.readings.count)}
    add_column(:support_materials, :readings_count, :integer)
    SupportMaterial.find(:all).each{|s| s.update_attribute_with_validation_skipping(:readings_count, s.readings.count)}
  end

  def self.down
    remove_column(:comments, :readings_count)
    remove_column(:support_materials, :readings_count)
  end
end
