class CreateAbstractRatings < ActiveRecord::Migration
  def self.up
    create_table :ratings do |t|
      t.column :value,          :integer,  :null => false   # the rating
      t.column :subject_id,     :integer,  :null => false   # what is being rated?
      t.column :participant_id, :integer # null false was force default 0 # by whom?
      t.column :created_on,     :datetime, :null => false   # when?
      t.column :type,           :string                     # use STI
    end
  end

  def self.down
    drop_table :ratings
  end
end
