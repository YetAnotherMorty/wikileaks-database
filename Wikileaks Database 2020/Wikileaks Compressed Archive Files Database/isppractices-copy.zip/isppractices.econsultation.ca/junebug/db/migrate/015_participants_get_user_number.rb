class ParticipantsGetUserNumber < ActiveRecord::Migration
  def self.up
    add_column :users, :user_number, :string # could be integer, but we don't know for sure
  end

  def self.down
    remove_column :users, :user_number
  end
end
