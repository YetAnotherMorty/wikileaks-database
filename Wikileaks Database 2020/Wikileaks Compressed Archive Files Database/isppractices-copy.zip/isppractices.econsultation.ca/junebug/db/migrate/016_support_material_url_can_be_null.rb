class SupportMaterialUrlCanBeNull < ActiveRecord::Migration
  def self.up
    change_column(:support_materials, :url, :string, :null => true)
  end

  def self.down
    change_column(:support_materials, :url, :string, :null => false)
  end
end
