class RegFilterItemsGetTopicAssociation < ActiveRecord::Migration
  def self.up
    add_column :registration_filter_items, :topic_id, :integer
  end

  def self.down
    remove_columb :registration_filter_items, :topic_id
  end
end
