class CreateTopics < ActiveRecord::Migration
  def self.up
    create_table :topics do |t|
      t.column :title,        :string
      t.column :introduction, :text,    :limit => 1000
      t.column :body_copy,    :text,    :limit => 65000
      t.column :for,          :date,                    :null => false
      t.column :author_id,    :integer,                 :null => false
      t.column :approved,     :binary
    end
  end

  def self.down
    drop_table :topics
  end
end
