class TopicsGetContinueReadingLinkText < ActiveRecord::Migration
  def self.up
    add_column(:topics, :continue_reading, :string, :default => 'Read the full piece')
  end

  def self.down
    remove_column(:topics, :continue_reading)
  end
end
