class FixSupReadingCount < ActiveRecord::Migration
  def self.up
    rename_column :support_materials, :readings_count, :reading_count
  end

  def self.down
    rename_column :support_materials, :reading_count,  :readings_count
  end
end
