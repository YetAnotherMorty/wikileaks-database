class CommentSubjectIsTopic < ActiveRecord::Migration
  def self.up
    rename_column :comments, :subject_id, :topic_id
    change_column :comments, :topic_id, :integer, :default => 0
  end

  def self.down
    rename_column :comments, :topic_id, :subject_id
  end
end
