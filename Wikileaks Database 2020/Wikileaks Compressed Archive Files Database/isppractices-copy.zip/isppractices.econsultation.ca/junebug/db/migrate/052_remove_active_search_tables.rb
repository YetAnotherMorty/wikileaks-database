# this migration reverses #39 and #45
class RemoveActiveSearchTables < ActiveRecord::Migration
  def self.up
    ActiveSearchTermsTable::down
    TopicsAreSearchable::down
  end

  def self.down
    ActiveSearchTermsTable::up
    TopicsAreSearchable::up
    IndexSearchTables::up # restore indexes
  end
end
