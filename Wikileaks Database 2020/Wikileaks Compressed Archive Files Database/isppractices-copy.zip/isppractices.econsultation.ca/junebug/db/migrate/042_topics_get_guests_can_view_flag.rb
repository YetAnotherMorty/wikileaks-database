class TopicsGetGuestsCanViewFlag < ActiveRecord::Migration
  def self.up
    add_column :topics, :guests_can_view, :boolean, :default => false
  end

  def self.down
    remove_column :topics, :guests_can_view
  end
end
