class TopicsAreSearchable < ActiveRecord::Migration
  def self.up
    create_table(:search_terms_topics, :id => false )do |t|
      t.column :topic_id,       :integer
      t.column :search_term_id, :integer
    end
  end

  def self.down
    drop_table :search_terms_topics
  end
end
