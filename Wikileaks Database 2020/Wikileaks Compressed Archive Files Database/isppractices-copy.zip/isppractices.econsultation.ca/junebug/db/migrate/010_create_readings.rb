class CreateReadings < ActiveRecord::Migration
  def self.up
    create_table :readings do |t|
      t.column :participant_id,      :integer, :null => false
      t.column :support_material_id, :integer, :null => false
      t.column :created_at,          :datetime
    end
  end

  def self.down
    drop_table :readings
  end
end
