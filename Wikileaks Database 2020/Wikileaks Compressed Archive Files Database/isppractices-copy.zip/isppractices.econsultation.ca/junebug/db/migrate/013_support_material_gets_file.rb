class SupportMaterialGetsFile < ActiveRecord::Migration
  def self.up
    add_column :support_materials, :file, :string
  end

  def self.down
    remove_column :support_materials, :file
  end
end
