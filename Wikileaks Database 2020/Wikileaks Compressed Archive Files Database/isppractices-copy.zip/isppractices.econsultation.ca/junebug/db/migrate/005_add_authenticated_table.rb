class AddAuthenticatedTable < ActiveRecord::Migration

  def self.up
    add_column :users, "email",            :string, :limit => 100
    add_column :users, "crypted_password", :string, :limit => 40
    add_column :users, "salt",             :string, :limit => 40
    add_column :users, "created_at",       :datetime
  end

  def self.down
    remove_column :users, "email"            
    remove_column :users, "crypted_password" 
    remove_column :users, "salt"             
    remove_column :users, "created_at"       
  end

end
