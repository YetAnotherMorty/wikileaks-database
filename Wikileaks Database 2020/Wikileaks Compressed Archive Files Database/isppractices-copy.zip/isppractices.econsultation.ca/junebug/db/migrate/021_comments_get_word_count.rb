class CommentsGetWordCount < ActiveRecord::Migration
  def self.up
    add_column :comments, :word_count, :integer
    Comment.find(:all).each{|c| c.save }
  end

  def self.down
    remove_column :comments, :word_count
  end
end
