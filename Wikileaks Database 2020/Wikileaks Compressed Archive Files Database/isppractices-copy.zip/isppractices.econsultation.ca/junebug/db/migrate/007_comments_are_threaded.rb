class CommentsAreThreaded < ActiveRecord::Migration
  def self.up
    add_column :comments, :root_id,   :integer, :default => 0
    add_column :comments, :parent_id, :integer, :default => 0
    add_column :comments, :lft,       :integer, :default => 0
    add_column :comments, :rgt,       :integer, :default => 0
    add_column :comments, :depth,     :integer, :default => 0
  end

  def self.down
    remove_column :comments, :root_id  
    remove_column :comments, :parent_id
    remove_column :comments, :lft      
    remove_column :comments, :rgt      
    remove_column :comments, :depth    
  end
end
