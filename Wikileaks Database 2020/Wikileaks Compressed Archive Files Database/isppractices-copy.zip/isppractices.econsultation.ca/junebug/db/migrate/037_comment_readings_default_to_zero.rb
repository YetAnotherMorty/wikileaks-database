# This is a continuation of migration 32 WorkAroundCounterCacheBug
class CommentReadingsDefaultToZero < ActiveRecord::Migration
  def self.up
    change_column :comments, :reading_count, :integer, :default => 0
    say_with_time "Setting Comment reading_count cache..." do
      Comment.find(:all).each do |comment|
        comment.update_attribute(:reading_count, comment.readings.count)
      end
    end
  end

  def self.down
  end
end
