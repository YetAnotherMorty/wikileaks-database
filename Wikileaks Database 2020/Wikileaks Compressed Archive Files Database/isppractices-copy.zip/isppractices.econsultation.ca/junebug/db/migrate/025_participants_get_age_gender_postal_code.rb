class ParticipantsGetAgeGenderPostalCode < ActiveRecord::Migration
  def self.up
    add_column(:users, :year_of_birth, :integer)
    add_column(:users, :gender, :integer, :default => 0)
    add_column(:users, :postal_code, :string)
  end

  def self.down
    remove_column(:users, :postal_code)
    remove_column(:users, :gender)
    remove_column(:users, :year_of_birth)
  end
end
