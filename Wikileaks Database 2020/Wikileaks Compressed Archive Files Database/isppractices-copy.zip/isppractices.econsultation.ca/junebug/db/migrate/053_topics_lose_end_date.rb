class TopicsLoseEndDate < ActiveRecord::Migration
  def self.up
    remove_column :topics, :end_date
  end

  def self.down
    raise IrreversibleMigration
  end
end
