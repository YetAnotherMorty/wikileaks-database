class CreateSupportMaterials < ActiveRecord::Migration
  def self.up
    create_table :support_materials do |t|
      t.column :name,     :string,  :null => false
      t.column :url,      :string,  :null => false
      t.column :topic_id, :integer, :null => false
    end
  end

  def self.down
    drop_table :support_materials
  end
end
