class CreateRegistrationFilterItems < ActiveRecord::Migration
  def self.up
    create_table :registration_filter_items do |t|
      t.column :type, :string
      t.column :value, :string
    end
  end

  def self.down
    drop_table :registration_filter_items
  end
end
