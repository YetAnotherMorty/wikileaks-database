class TopicGetsPrivacy < ActiveRecord::Migration
  def self.up
    rename_column :topics, :guests_can_view, :private
  end

  def self.down
    rename_column :topics, :private, :guests_can_view
  end
end
