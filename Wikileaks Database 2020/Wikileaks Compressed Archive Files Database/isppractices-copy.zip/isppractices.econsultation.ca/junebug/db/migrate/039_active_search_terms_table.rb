class ActiveSearchTermsTable < ActiveRecord::Migration
  def self.up
    create_table :search_terms do |t|
      t.column :term, :string
    end
    create_table(:comments_search_terms, :id => false )do |t|
      t.column :comment_id,     :integer
      t.column :search_term_id, :integer
    end
  end

  def self.down
    drop_table :comments_search_terms;
    drop_table :search_terms
  end
end
