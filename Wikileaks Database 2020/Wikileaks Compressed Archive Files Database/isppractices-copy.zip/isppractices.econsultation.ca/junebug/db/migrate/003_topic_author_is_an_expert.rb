class TopicAuthorIsAnExpert < ActiveRecord::Migration
  def self.up
    rename_column :topics, :author_id, :expert_id
  end

  def self.down
    rename_column :topics, :expert_id, :author_id
  end
end
