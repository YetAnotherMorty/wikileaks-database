class CommentsGetRemovedFlag < ActiveRecord::Migration
  def self.up
    add_column :comments, :removed, :boolean, :default => false
  end

  def self.down
    remove_column :comments, :removed
  end
end
