class TopicsGetFrontPageWorthy < ActiveRecord::Migration
  def self.up
    add_column :topics, :front_page_worthy, :boolean, :default => true
  end

  def self.down
    remove_column :topics, :front_page_worthy
  end
end
