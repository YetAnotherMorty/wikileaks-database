class TopicLoosesEndDate < ActiveRecord::Migration
  def self.up
    remove_column :topics, :end_date
  end

  def self.down
    add_column :topics, :end_date, :date, :null => false
    Topic.update_all("end_date = start_date")
  end
end
