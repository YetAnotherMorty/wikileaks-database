module Provinces
  PROVINCES =[['Alberta',                   "AB"] ,
              ['British Columbia',          "BC"] ,
              ['Manitoba',                  "MB"] ,
              ['New Brunswick',             "NB"] ,
              ['Newfoundland and Labrador', "NL"] ,
              ['Northwest Territories',     "NT"] ,
              ['Nova Scotia',               "NS"] ,
              ['Nunavut',                   "NU"] ,
              ['Ontario',                   "ON"] ,
              ['Prince Edward Island',      "PE"] ,
              ['Québec',                    "QC"] ,
              ['Saskatchewan',              "SK"] ,
              ['Yukon',                     "YT"] ]
  
  def Provinces.full_name(code='')
    return nil unless code
    PROVINCES.rassoc(code.upcase) && PROVINCES.rassoc(code.upcase).first
  end
end