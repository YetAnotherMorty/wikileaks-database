require 'csv'

module CsvWritter
  def self.array_of_AR_to_CSV(array_of_AR_objects)
    buffer = String.new # write buffer
    writer = ::CSV::BasicWriter.new(buffer)
    array_of_AR_objects.each do | rec |
      writer << rec.attributes.values
    end
    return buffer
  end
end
