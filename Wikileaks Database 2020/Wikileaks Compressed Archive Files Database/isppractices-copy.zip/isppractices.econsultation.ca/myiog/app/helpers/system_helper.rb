module SystemHelper

  def link_table_rows(array_of_models)
    array_of_models.collect do |model|
        content_tag( :tr, 
          content_tag( :td, "#{model.humanize} ") +
          content_tag( :td, link_to('show', {:action => 'show', :model => model}, :class => 'show-table' ) ) +
          content_tag( :td, link_to('download', {:action => 'export', :model => model}, :class => 'export') )
        ) 
    end    
  end
end
