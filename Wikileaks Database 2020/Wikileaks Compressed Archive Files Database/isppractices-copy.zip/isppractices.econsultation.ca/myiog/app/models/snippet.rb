# Schema as of Mon Nov 27 15:17:56 EST 2006 (schema version 35)
#
#  id                  :integer(11)   not null
#  name                :string(255)   
#  body                :text          
#

class Snippet < ActiveRecord::Base
end
