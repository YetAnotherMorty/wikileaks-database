# Schema as of Mon Nov 27 15:17:56 EST 2006 (schema version 35)
#
#  id                  :integer(11)   not null
#  value               :integer(11)   default(0), not null
#  subject_id          :integer(11)   default(0), not null
#  participant_id      :integer(11)   
#  created_on          :datetime      not null
#  type                :string(255)   
#

class MaterialInformativeRating < AbstractRating
  belongs_to :subject, :class_name => 'SupportMaterial', :foreign_key => 'subject_id'
  
  def mapping
    # TODO these strings should be stored as application settings
    [ 
      [1, 'informative'], 
      [2, 'somewhat informative'], 
      [77, 'unsure'],
      [3, 'somewhat uninformative'],
      [4, 'uninformative']
    ]
  end

  def select_intro
    '...'
  end

end
