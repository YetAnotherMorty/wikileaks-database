[2006/01/09 20:57:02, 1] smbd/service.c:make_connection_snum(642)
  c (82.253.36.52) connect to service ARCHIVOSERVR initially as user nobody (uid=65534, gid=65534) (pid 16735)
[2006/01/09 20:57:03, 1] smbd/service.c:close_cnum(830)
  c (82.253.36.52) closed connection to service ARCHIVOSERVR
[2006/01/09 20:57:04, 1] smbd/service.c:make_connection_snum(642)
  c (82.253.36.52) connect to service ARCHIVOSERVR initially as user nobody (uid=65534, gid=65534) (pid 16744)
[2006/01/09 20:57:43, 1] smbd/service.c:close_cnum(830)
  c (82.253.36.52) closed connection to service ARCHIVOSERVR
