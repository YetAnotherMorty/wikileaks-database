[2005/08/22 16:34:30, 1] smbd/service.c:make_connection_snum(642)
  m (213.47.197.210) connect to service print$ initially as user nobody (uid=65534, gid=65534) (pid 4685)
[2005/08/22 16:34:31, 1] smbd/service.c:close_cnum(830)
  m (213.47.197.210) closed connection to service print$
[2005/08/22 16:34:32, 1] smbd/service.c:make_connection_snum(642)
  m (213.47.197.210) connect to service print$ initially as user nobody (uid=65534, gid=65534) (pid 4702)
[2005/08/22 16:34:32, 1] smbd/service.c:close_cnum(830)
  m (213.47.197.210) closed connection to service print$
[2005/08/22 16:34:33, 1] smbd/service.c:make_connection_snum(642)
  m (213.47.197.210) connect to service print$ initially as user nobody (uid=65534, gid=65534) (pid 4719)
[2005/08/22 16:34:39, 1] smbd/service.c:close_cnum(830)
  m (213.47.197.210) closed connection to service print$
[2005/08/22 16:34:43, 1] smbd/service.c:make_connection_snum(642)
  m (213.47.197.210) connect to service MISU_SERVER initially as user nobody (uid=65534, gid=65534) (pid 4795)
[2005/08/22 16:34:54, 1] smbd/service.c:close_cnum(830)
  m (213.47.197.210) closed connection to service MISU_SERVER
[2005/08/22 16:34:55, 1] smbd/service.c:make_connection_snum(642)
  m (213.47.197.210) connect to service MISU_SERVER initially as user nobody (uid=65534, gid=65534) (pid 4892)
[2005/08/22 16:35:07, 1] smbd/service.c:close_cnum(830)
  m (213.47.197.210) closed connection to service MISU_SERVER
[2005/08/22 16:35:07, 1] smbd/service.c:make_connection_snum(642)
  m (213.47.197.210) connect to service MISU_SERVER initially as user nobody (uid=65534, gid=65534) (pid 4999)
[2005/08/22 16:35:17, 1] smbd/service.c:close_cnum(830)
  m (213.47.197.210) closed connection to service MISU_SERVER
[2005/08/22 16:35:39, 0] smbd/service.c:make_connection(794)
  m (213.47.197.210) couldn't find service c$
[2005/08/22 16:35:42, 0] smbd/service.c:make_connection(794)
  m (213.47.197.210) couldn't find service c$
[2005/08/22 16:35:45, 0] smbd/service.c:make_connection(794)
  m (213.47.197.210) couldn't find service c$
[2005/08/22 16:35:48, 1] smbd/service.c:make_connection_snum(642)
  m (213.47.197.210) connect to service print$ initially as user nobody (uid=65534, gid=65534) (pid 5322)
[2005/08/22 16:36:04, 1] smbd/service.c:close_cnum(830)
  m (213.47.197.210) closed connection to service print$
[2005/08/22 16:36:06, 1] smbd/service.c:make_connection_snum(642)
  m (213.47.197.210) connect to service print$ initially as user nobody (uid=65534, gid=65534) (pid 5475)
[2005/08/22 16:36:32, 1] smbd/service.c:close_cnum(830)
  m (213.47.197.210) closed connection to service print$
[2005/08/22 16:36:35, 1] smbd/service.c:make_connection_snum(642)
  m (213.47.197.210) connect to service print$ initially as user nobody (uid=65534, gid=65534) (pid 5700)
[2005/08/22 16:36:41, 1] smbd/service.c:close_cnum(830)
  m (213.47.197.210) closed connection to service print$
[2005/08/22 16:36:42, 0] smbd/service.c:make_connection(794)
  m (213.47.197.210) couldn't find service c
[2005/08/22 16:36:45, 0] smbd/service.c:make_connection(794)
  m (213.47.197.210) couldn't find service c
[2005/08/22 16:36:48, 0] smbd/service.c:make_connection(794)
  m (213.47.197.210) couldn't find service c
[2005/08/22 16:36:50, 0] smbd/service.c:make_connection(794)
  m (213.47.197.210) couldn't find service d$
[2005/08/22 16:36:52, 0] smbd/service.c:make_connection(794)
  m (213.47.197.210) couldn't find service d$
[2005/08/22 16:36:53, 0] smbd/service.c:make_connection(794)
  m (213.47.197.210) couldn't find service d$
[2005/08/22 16:36:56, 0] smbd/service.c:make_connection(794)
  m (213.47.197.210) couldn't find service e$
[2005/08/22 16:37:00, 0] smbd/service.c:make_connection(794)
  m (213.47.197.210) couldn't find service e$
[2005/08/22 16:37:05, 0] smbd/service.c:make_connection(794)
  m (213.47.197.210) couldn't find service e$
