/* JSON Loader */
bbc.fmtj.queue.register({namespace:"bbc.fmtj.net.json.model",method:"addModule",script:"http://newsimg.bbc.co.uk/js/app/shared/net/json/v2_8/jsonloader.js"});
/* Picture Gallery */
bbc.fmtj.queue.register({namespace:"bbc.fmtj.apps.pictureGallery",method:"createGallery",scripts:{foot:["http://newsimg.bbc.co.uk/js/app/carousel/v1_4/carousel.js","http://newsimg.bbc.co.uk/js/app/slideshow/v1_4/slideshow.js","http://newsimg.bbc.co.uk/js/app/picture_gallery/v1_5/picture_gallery.js"]}});
/* Carousel */
bbc.fmtj.queue.register({namespace:"bbc.fmtj.apps.carousel",method:"createCarousel",script:"http://newsimg.bbc.co.uk/js/app/carousel/v1_4/carousel.js"});
/* Slideshow */
bbc.fmtj.queue.register({namespace:"bbc.fmtj.apps.slideshow",method:"createSlideShow",script:"http://newsimg.bbc.co.uk/js/app/slideshow/v1_4/slideshow.js"});
/* EMP */
bbc.fmtj.queue.register({namespace:"bbc.fmtj.av.emp",method:"load",scripts: {foot: [ "http://newsimg.bbc.co.uk/js/app/av/emp/emp.js?2.18_13034_14207_20091029165002" ]}});