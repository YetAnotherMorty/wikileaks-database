getrss=function(o){
	this.helpURl="http://news.bbc.co.uk/1/hi/help/3223484.stm";
	this.site=o.site;
	this.rssURI=this._getFeedUri();
	this.contentFlavour=this.isIndex();
	this._createRssElement(this.rssURI);
}
getrss.prototype={
	isIndex:function(){
	var metaTags=document.getElementsByTagName("meta");
		for(var i=0;i<metaTags.length;i++){
			if(metaTags[i].getAttribute('content')=="INDEX"){return true}
		}
	},
	_createRssElement:function(rssURI){
		document.write(this._getRssLinkMarkup(rssURI));	
	},
	_getFeedUri:function(){
		var linkTags=document.getElementsByTagName("link");
		for(var i=0;i<linkTags.length;i++){
			switch(linkTags[i].getAttribute('type')){
			case"application/rss+xml":
				rssURI=linkTags[i].getAttribute('href');return rssURI;
			break;
		}
	}
	},
	_getRssLinkMarkup:function(rssURI){
		if(this.site=="sport"){
			var list='<li class="rssFeed"><a style="" href="'+rssURI+'">'
			+'<span class="offscreen">RSS feed</span></a></li>'
		}
		else{
			var list='<li class="rssFeed"><a style="" href="'+rssURI+'">'
			+'<span class="offscreen">RSS feed</span></a></li>'
		}
	return list
	}
}

