window.name="main";
function aodpopup(URL){
window.open(URL,'aod','width=693,height=525,toolbar=no,personalbar=no,location=no,directories=no,statusbar=no,menubar=no,status=no,resizable=yes,left=60,screenX=60,top=100,screenY=100');
}
if(location.search.substring(1)=="focuswin"){
	window.focus();
}